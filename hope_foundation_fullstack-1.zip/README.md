# Hope Foundation — Full-Stack NGO Website Starter

A runnable starter for an NGO donation-management website:
- Responsive public website
- Donation, project, fund-usage, and volunteer sections
- Donor registration/login and donor dashboard
- Admin login/dashboard for managing projects, donations, expenses, and volunteer requests
- FastAPI REST API + SQLite database
- Demo admin account seeded on first run

## Stack
- Frontend: HTML, CSS, vanilla JavaScript (easy to customize)
- Backend: Python + FastAPI
- Database: SQLite (for local development)

## Run locally
1. Install Python 3.10+.
2. Open a terminal in the `backend` folder.
3. Run: `python -m venv .venv`
4. Activate the environment:
   - Windows: `.venv\\Scripts\\activate`
   - macOS/Linux: `source .venv/bin/activate`
5. Run: `pip install -r requirements.txt`
6. Run: `uvicorn main:app --reload`
7. Open `http://127.0.0.1:8000` in your browser.

Demo admin login:
- Email: `admin@hopefoundation.local`
- Password: `ChangeMe123!`

Change this password and configure production security before deploying.

## Important production notes
This is a functional development starter, not a production-ready donation/payment system. Before public launch:
- Replace demo auth with hardened authentication, rate limits, secure session/cookie strategy, email verification, password reset, and MFA for admins.
- Add CSRF protections where applicable, strict CORS, HTTPS, backups, monitoring, and security testing.
- Integrate a PCI-compliant payment gateway (for example, Razorpay/Stripe where supported); never store card numbers, CVV, UPI PINs, or banking passwords.
- Verify NGO registration, tax/80G/FCRA applicability, receipts, accounting, privacy notice, consent, and legal obligations with qualified professionals.
- Store uploaded documents/media in private object storage with malware scanning and access controls.
- Keep immutable audit logs and restrict staff access using least privilege.
