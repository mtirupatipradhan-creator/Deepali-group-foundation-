from pathlib import Path
import sqlite3, os
from datetime import datetime, timezone
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from passlib.context import CryptContext
import secrets

BASE = Path(__file__).resolve().parent.parent
DB = Path(__file__).resolve().parent / "hope.db"
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
app = FastAPI(title="Hope Foundation API", version="1.0.0")
tokens = {}  # Development-only in-memory tokens; use durable secure sessions in production.

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'donor', phone TEXT DEFAULT '',
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS projects(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          category TEXT DEFAULT 'Community', description TEXT DEFAULT '',
          goal REAL DEFAULT 0, raised REAL DEFAULT 0, image_url TEXT DEFAULT '',
          status TEXT DEFAULT 'Active', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS donations(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
          donor_name TEXT NOT NULL, donor_email TEXT DEFAULT '',
          amount REAL NOT NULL, project_id INTEGER, payment_method TEXT DEFAULT 'Manual',
          payment_status TEXT DEFAULT 'Pending', reference TEXT DEFAULT '',
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS expenses(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          category TEXT DEFAULT 'Program', amount REAL NOT NULL,
          spent_on TEXT NOT NULL, notes TEXT DEFAULT '', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS volunteers(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          email TEXT NOT NULL, phone TEXT DEFAULT '', interest TEXT DEFAULT '',
          message TEXT DEFAULT '', status TEXT DEFAULT 'New', created_at TEXT NOT NULL);
        """)
        row = c.execute("SELECT id FROM users WHERE email=?", ("admin@hopefoundation.local",)).fetchone()
        if not row:
            c.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                      ("Foundation Admin", "admin@hopefoundation.local", pwd.hash("ChangeMe123!"), "admin", now()))
        if c.execute("SELECT COUNT(*) FROM projects").fetchone()[0] == 0:
            c.executemany("""INSERT INTO projects(title,category,description,goal,raised,status,created_at)
                           VALUES(?,?,?,?,?,?,?)""", [
                ("Education for Every Child", "Education", "Learning materials, school support, and mentoring for children.", 250000, 86500, "Active", now()),
                ("Community Health Camps", "Healthcare", "Local health awareness, screenings, and essential care.", 180000, 72400, "Active", now()),
                ("Food & Essentials", "Community", "Nutritious meals and essential supplies for families.", 120000, 51800, "Active", now()),
            ])

def now():
    return datetime.now(timezone.utc).isoformat()

@app.on_event("startup")
def startup():
    init_db()

class RegisterIn(BaseModel):
    name: str
    email: str
    password: str
    phone: str = ""

class LoginIn(BaseModel):
    email: str
    password: str

class DonationIn(BaseModel):
    donor_name: str
    donor_email: str = ""
    amount: float
    project_id: Optional[int] = None
    payment_method: str = "Manual"
    reference: str = ""

class ProjectIn(BaseModel):
    title: str
    category: str = "Community"
    description: str = ""
    goal: float = 0
    image_url: str = ""
    status: str = "Active"

class ExpenseIn(BaseModel):
    title: str
    category: str = "Program"
    amount: float
    spent_on: str
    notes: str = ""

class VolunteerIn(BaseModel):
    name: str
    email: str
    phone: str = ""
    interest: str = ""
    message: str = ""

def current_user(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        return None
    return tokens.get(authorization[7:])

def require_user(authorization: Optional[str] = Header(default=None)):
    u = current_user(authorization)
    if not u:
        raise HTTPException(401, "Please log in first")
    return u

def require_admin(u=Depends(require_user)):
    if u["role"] != "admin":
        raise HTTPException(403, "Admin access required")
    return u

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "Hope Foundation API"}

@app.post("/api/auth/register")
def register(data: RegisterIn):
    if len(data.password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    with db() as c:
        try:
            cur = c.execute("INSERT INTO users(name,email,password_hash,role,phone,created_at) VALUES(?,?,?,?,?,?)",
                (data.name.strip(), data.email.lower().strip(), pwd.hash(data.password), "donor", data.phone, now()))
            user_id = cur.lastrowid
        except sqlite3.IntegrityError:
            raise HTTPException(409, "An account with this email already exists")
    token = secrets.token_urlsafe(32)
    user = {"id": user_id, "name": data.name, "email": data.email.lower(), "role": "donor"}
    tokens[token] = user
    return {"token": token, "user": user}

@app.post("/api/auth/login")
def login(data: LoginIn):
    with db() as c:
        row = c.execute("SELECT * FROM users WHERE email=?", (data.email.lower().strip(),)).fetchone()
    if not row or not pwd.verify(data.password, row["password_hash"]):
        raise HTTPException(401, "Email or password is incorrect")
    token = secrets.token_urlsafe(32)
    user = {"id": row["id"], "name": row["name"], "email": row["email"], "role": row["role"]}
    tokens[token] = user
    return {"token": token, "user": user}

@app.get("/api/auth/me")
def me(u=Depends(require_user)):
    return u

@app.post("/api/auth/logout")
def logout(authorization: Optional[str] = Header(default=None)):
    if authorization and authorization.startswith("Bearer "):
        tokens.pop(authorization[7:], None)
    return {"ok": True}

@app.get("/api/public/stats")
def stats():
    with db() as c:
        donors = c.execute("SELECT COUNT(DISTINCT donor_email) FROM donations WHERE payment_status='Verified'").fetchone()[0]
        total = c.execute("SELECT COALESCE(SUM(amount),0) FROM donations WHERE payment_status='Verified'").fetchone()[0]
        projects = c.execute("SELECT COUNT(*) FROM projects WHERE status='Active'").fetchone()[0]
        spent = c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]
    return {"donors": donors, "raised": total, "projects": projects, "spent": spent}

@app.get("/api/public/projects")
def projects():
    with db() as c:
        rows = c.execute("SELECT * FROM projects WHERE status='Active' ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/public/expenses")
def public_expenses():
    with db() as c:
        rows = c.execute("SELECT id,title,category,amount,spent_on,notes FROM expenses ORDER BY spent_on DESC LIMIT 50").fetchall()
    return [dict(r) for r in rows]

@app.post("/api/public/donations")
def create_donation(data: DonationIn, u=Depends(current_user)):
    if data.amount <= 0:
        raise HTTPException(400, "Donation amount must be greater than zero")
    with db() as c:
        cur = c.execute("""INSERT INTO donations(user_id,donor_name,donor_email,amount,project_id,payment_method,payment_status,reference,created_at)
                           VALUES(?,?,?,?,?,?,?,?,?)""",
             (u["id"] if u else None, data.donor_name, data.donor_email, data.amount, data.project_id,
              data.payment_method, "Pending", data.reference, now()))
    return {"id": cur.lastrowid, "status": "Pending", "message": "Donation recorded for admin verification. No payment was taken."}

@app.post("/api/public/volunteers")
def volunteer(data: VolunteerIn):
    with db() as c:
        cur = c.execute("INSERT INTO volunteers(name,email,phone,interest,message,created_at) VALUES(?,?,?,?,?,?)",
            (data.name, data.email, data.phone, data.interest, data.message, now()))
    return {"id": cur.lastrowid, "message": "Thank you. Your volunteer request has been submitted."}

@app.get("/api/donor/donations")
def donor_donations(u=Depends(require_user)):
    with db() as c:
        rows = c.execute("SELECT * FROM donations WHERE user_id=? OR lower(donor_email)=? ORDER BY id DESC",
                         (u["id"], u["email"].lower())).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/admin/summary")
def admin_summary(u=Depends(require_admin)):
    with db() as c:
        return {
          "donations": c.execute("SELECT COUNT(*) FROM donations").fetchone()[0],
          "pending": c.execute("SELECT COUNT(*) FROM donations WHERE payment_status='Pending'").fetchone()[0],
          "verified_total": c.execute("SELECT COALESCE(SUM(amount),0) FROM donations WHERE payment_status='Verified'").fetchone()[0],
          "expenses": c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0],
          "volunteers": c.execute("SELECT COUNT(*) FROM volunteers WHERE status='New'").fetchone()[0]
        }

@app.get("/api/admin/donations")
def admin_donations(u=Depends(require_admin)):
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM donations ORDER BY id DESC").fetchall()]

@app.patch("/api/admin/donations/{donation_id}/verify")
def verify_donation(donation_id: int, u=Depends(require_admin)):
    with db() as c:
        row = c.execute("SELECT * FROM donations WHERE id=?", (donation_id,)).fetchone()
        if not row: raise HTTPException(404, "Donation not found")
        c.execute("UPDATE donations SET payment_status='Verified' WHERE id=?", (donation_id,))
        if row["project_id"]:
            c.execute("UPDATE projects SET raised=raised+? WHERE id=?", (row["amount"], row["project_id"]))
    return {"ok": True}

@app.get("/api/admin/projects")
def admin_projects(u=Depends(require_admin)):
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM projects ORDER BY id DESC").fetchall()]

@app.post("/api/admin/projects")
def add_project(data: ProjectIn, u=Depends(require_admin)):
    with db() as c:
        cur = c.execute("INSERT INTO projects(title,category,description,goal,image_url,status,created_at) VALUES(?,?,?,?,?,?,?)",
          (data.title,data.category,data.description,data.goal,data.image_url,data.status,now()))
    return {"id": cur.lastrowid}

@app.delete("/api/admin/projects/{project_id}")
def delete_project(project_id: int, u=Depends(require_admin)):
    with db() as c:
        c.execute("DELETE FROM projects WHERE id=?", (project_id,))
    return {"ok": True}

@app.get("/api/admin/expenses")
def admin_expenses(u=Depends(require_admin)):
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM expenses ORDER BY id DESC").fetchall()]

@app.post("/api/admin/expenses")
def add_expense(data: ExpenseIn, u=Depends(require_admin)):
    if data.amount <= 0: raise HTTPException(400, "Amount must be positive")
    with db() as c:
        cur = c.execute("INSERT INTO expenses(title,category,amount,spent_on,notes,created_at) VALUES(?,?,?,?,?,?)",
          (data.title,data.category,data.amount,data.spent_on,data.notes,now()))
    return {"id": cur.lastrowid}

@app.get("/api/admin/volunteers")
def admin_volunteers(u=Depends(require_admin)):
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM volunteers ORDER BY id DESC").fetchall()]

@app.patch("/api/admin/volunteers/{volunteer_id}")
def update_volunteer(volunteer_id: int, status: str, u=Depends(require_admin)):
    if status not in ("New","Contacted","Approved","Declined"): raise HTTPException(400, "Invalid status")
    with db() as c:
        c.execute("UPDATE volunteers SET status=? WHERE id=?", (status,volunteer_id))
    return {"ok": True}

# Serve the frontend from the same origin.
app.mount("/assets", StaticFiles(directory=BASE / "frontend"), name="assets")
@app.get("/")
def home():
    return FileResponse(BASE / "frontend" / "index.html")
