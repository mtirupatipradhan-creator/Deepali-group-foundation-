const API = "/api";
let authToken = localStorage.getItem("hope_token") || "";
let currentUser = JSON.parse(localStorage.getItem("hope_user") || "null");
let authMode = "login";
let allProjects = [];
const $ = s => document.querySelector(s);
const money = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(Number(n||0));
async function api(path, options={}) {
  const headers = {"Content-Type":"application/json", ...(options.headers||{})};
  if(authToken) headers.Authorization = `Bearer ${authToken}`;
  const response = await fetch(API+path,{...options,headers});
  const data = response.status===204 ? null : await response.json().catch(()=>({detail:"Unexpected server response"}));
  if(!response.ok) throw new Error(data.detail || "Request failed");
  return data;
}
function message(el,text,error=false){el.textContent=text;el.classList.toggle("error",error)}
function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function loadHome(){
  try{
    const [stats,projects,expenses]=await Promise.all([api("/public/stats"),api("/public/projects"),api("/public/expenses")]);
    $("#statDonors").textContent=Number(stats.donors).toLocaleString("en-IN");
    $("#statRaised").textContent=money(stats.raised);
    $("#statProjects").textContent=stats.projects;
    $("#spentTotal").textContent=money(stats.spent);
    allProjects=projects;
    $("#projectGrid").innerHTML=projects.length?projects.map((p,i)=>`<article class="project-card"><div class="project-image">${p.image_url?`<img src="${esc(p.image_url)}" alt="${esc(p.title)}">`:["📚","✳","♡"][i%3]}<span class="project-tag">${esc(p.category)}</span></div><div class="project-body"><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p><div class="progress-meta"><span>Raised ${money(p.raised)}</span><strong>${p.goal?Math.min(100,Math.round(p.raised/p.goal*100)):0}%</strong></div><div class="progress"><span style="width:${p.goal?Math.min(100,p.raised/p.goal*100):0}%"></span></div><div class="project-actions"><strong>Goal ${money(p.goal)}</strong><button aria-label="Donate to ${esc(p.title)}" data-donate-project="${p.id}">↗</button></div></div></article>`).join(""):'<p class="muted">Projects will appear here soon.</p>';
    $("#donationProject").innerHTML='<option value="">Where it is needed most</option>'+projects.map(p=>`<option value="${p.id}">${esc(p.title)}</option>`).join("");
    $("#expenseList").innerHTML=expenses.length?expenses.map(e=>`<div class="expense-item"><div><strong>${esc(e.title)}</strong><small>${esc(e.category)} · ${esc(e.spent_on)}</small></div><b>${money(e.amount)}</b></div>`).join(""):'<p class="muted">No expenses have been published yet.</p>';
  }catch(e){$("#projectGrid").innerHTML='<p class="muted">Could not load project data. Make sure the backend server is running.</p>'}
}
function openModal(id){$(id).classList.add("open");document.body.style.overflow="hidden"}
function closeModals(){document.querySelectorAll(".modal-backdrop").forEach(m=>m.classList.remove("open"));document.body.style.overflow=""}
function setAuthMode(mode){authMode=mode;document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("active",b.dataset.tab===mode));$("#registerFields").hidden=mode!=="register";$("#authTitle").textContent=mode==="login"?"Log in to your account":"Create your donor account";$("#authSubtitle").textContent=mode==="login"?"View your giving history and stay connected.":"Join our community of people creating change.";$("#authSubmit").textContent=mode==="login"?"Log in":"Create account";$("#authMessage").textContent=""}
function showAuth(admin=false){setAuthMode("login");$("#authForm").dataset.admin=admin?"true":"false";$("#authTitle").textContent=admin?"Admin portal login":"Log in to your account";$("#authSubtitle").textContent=admin?"Authorized foundation administrators only.":"View your giving history and stay connected.";openModal("#authModal")}
function persistAuth(data){authToken=data.token;currentUser=data.user;localStorage.setItem("hope_token",authToken);localStorage.setItem("hope_user",JSON.stringify(currentUser))}
$("#loginOpen").addEventListener("click",()=>currentUser?showDashboard():showAuth());
$("#adminOpen").addEventListener("click",e=>{e.preventDefault();showAuth(true)});
$("#adminShortcut").addEventListener("click",()=>{showAuth(true)});
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",closeModals));
document.querySelectorAll(".modal-backdrop").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModals()}));
document.querySelectorAll("[data-tab]").forEach(b=>b.addEventListener("click",()=>setAuthMode(b.dataset.tab)));
$("#menuToggle").addEventListener("click",()=>$("#nav").classList.toggle("open"));
$("#nav").querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>$("#nav").classList.remove("open")));
document.querySelectorAll("[data-amount]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll("[data-amount]").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");$("#amount").value=b.dataset.amount}));
document.addEventListener("click",e=>{const b=e.target.closest("[data-donate-project]");if(b){$("#donationProject").value=b.dataset.donateProject;$("#donate").scrollIntoView({behavior:"smooth"})}});
$("#authForm").addEventListener("submit",async e=>{
 e.preventDefault();const f=new FormData(e.target);const adminOnly=e.target.dataset.admin==="true";const payload={email:f.get("email"),password:f.get("password")};
 if(authMode==="register"){payload.name=f.get("name");payload.phone=f.get("phone")||""}
 try{const data=await api(authMode==="login"?"/auth/login":"/auth/register",{method:"POST",body:JSON.stringify(payload)});
 if(adminOnly&&data.user.role!=="admin"){await api("/auth/logout",{method:"POST"});throw new Error("This account is not an administrator.")}
 persistAuth(data);closeModals();if(data.user.role==="admin")showDashboard();else showDashboard();
 }catch(err){message($("#authMessage"),err.message,true)}
});
$("#donationForm").addEventListener("submit",async e=>{
 e.preventDefault();const f=new FormData(e.target);const payload={donor_name:f.get("donor_name"),donor_email:f.get("donor_email"),amount:Number(f.get("amount")),project_id:f.get("project_id")?Number(f.get("project_id")):null,payment_method:"Manual"};
 try{const r=await api("/public/donations",{method:"POST",body:JSON.stringify(payload)});message($("#donationMessage"),`Request #${r.id} recorded as pending. ${r.message}`);e.target.reset();$("#amount").value=1000}catch(err){message($("#donationMessage"),err.message,true)}
});
$("#volunteerForm").addEventListener("submit",async e=>{
 e.preventDefault();const f=new FormData(e.target);const payload=Object.fromEntries(f.entries());
 try{const r=await api("/public/volunteers",{method:"POST",body:JSON.stringify(payload)});message($("#volunteerMessage"),r.message);e.target.reset()}catch(err){message($("#volunteerMessage"),err.message,true)}
});
async function showDashboard(){
 if(!currentUser){showAuth();return}
 openModal("#dashboardModal");$("#dashboardTitle").textContent=`Hello, ${currentUser.name}`;
 const box=$("#dashboardContent");box.innerHTML='<p class="muted">Loading your dashboard…</p>';
 try{
  if(currentUser.role==="admin"){
   const s=await api("/admin/summary");
   box.innerHTML=`<div class="dashboard-cards"><div class="dashboard-card"><small>Total requests</small><strong>${s.donations}</strong></div><div class="dashboard-card"><small>Pending verification</small><strong>${s.pending}</strong></div><div class="dashboard-card"><small>Verified donations</small><strong>${money(s.verified_total)}</strong></div><div class="dashboard-card"><small>Recorded expenses</small><strong>${money(s.expenses)}</strong></div><div class="dashboard-card"><small>New volunteers</small><strong>${s.volunteers}</strong></div></div><h3 class="dashboard-section-title">Donation verification</h3><div id="adminDonations"><p class="muted">Loading donation records…</p></div><h3 class="dashboard-section-title">Add a project</h3><form id="addProjectForm" class="admin-inline"><label>Title<input name="title" required></label><label>Category<input name="category" value="Community"></label><label>Goal (₹)<input name="goal" type="number" min="0" value="50000"></label><label>Description<input name="description"></label><button class="btn btn-primary" type="submit">Add project</button><div class="form-message" id="projectMessage"></div></form><h3 class="dashboard-section-title">Record fund usage</h3><form id="addExpenseForm" class="admin-inline"><label>Expense title<input name="title" required></label><label>Category<input name="category" value="Program"></label><label>Amount (₹)<input name="amount" type="number" min="1" required></label><label>Date<input name="spent_on" type="date" required></label><label>Notes<input name="notes"></label><button class="btn btn-primary" type="submit">Save expense</button><div class="form-message" id="expenseMessage"></div></form><h3 class="dashboard-section-title">Volunteer requests</h3><div id="adminVolunteers"><p class="muted">Loading requests…</p></div>`;
   loadAdminTables();
   $("#addProjectForm").addEventListener("submit",async ev=>{ev.preventDefault();const f=new FormData(ev.target);try{await api("/admin/projects",{method:"POST",body:JSON.stringify({title:f.get("title"),category:f.get("category"),goal:Number(f.get("goal")),description:f.get("description")})});message($("#projectMessage"),"Project added.");ev.target.reset();await loadHome()}catch(err){message($("#projectMessage"),err.message,true)}});
   $("#addExpenseForm").addEventListener("submit",async ev=>{ev.preventDefault();const f=new FormData(ev.target);try{await api("/admin/expenses",{method:"POST",body:JSON.stringify({title:f.get("title"),category:f.get("category"),amount:Number(f.get("amount")),spent_on:f.get("spent_on"),notes:f.get("notes")})});message($("#expenseMessage"),"Expense recorded.");ev.target.reset();await loadHome()}catch(err){message($("#expenseMessage"),err.message,true)}});
  }else{
   const rows=await api("/donor/donations");box.innerHTML=`<div class="dashboard-cards"><div class="dashboard-card"><small>Donation records</small><strong>${rows.length}</strong></div><div class="dashboard-card"><small>Verified giving</small><strong>${money(rows.filter(x=>x.payment_status==="Verified").reduce((a,x)=>a+x.amount,0))}</strong></div></div><h3 class="dashboard-section-title">Your donation history</h3>${rows.length?`<table class="admin-table"><thead><tr><th>Reference</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead><tbody>${rows.map(r=>`<tr><td>#${r.id}</td><td>${money(r.amount)}</td><td>${esc(r.payment_status)}</td><td>${esc((r.created_at||"").slice(0,10))}</td></tr>`).join("")}</tbody></table>`:'<div class="empty-state">No donation records linked to this account yet. Use the donation form to get started.</div>'}`;
  }
 }catch(err){box.innerHTML=`<div class="empty-state">${esc(err.message)}. Please log in again.</div>`}
}
async function loadAdminTables(){
 try{
 const donations=await api("/admin/donations");
 $("#adminDonations").innerHTML=donations.length?`<table class="admin-table"><thead><tr><th>Donor</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>${donations.map(d=>`<tr><td>${esc(d.donor_name)}<br><small>${esc(d.donor_email)}</small></td><td>${money(d.amount)}</td><td>${esc(d.payment_status)}</td><td>${d.payment_status==="Pending"?`<button data-verify="${d.id}">Verify</button>`:"—"}</td></tr>`).join("")}</tbody></table>`:'<div class="empty-state">No donation requests yet.</div>';
 const volunteers=await api("/admin/volunteers");
 $("#adminVolunteers").innerHTML=volunteers.length?`<table class="admin-table"><thead><tr><th>Name / contact</th><th>Interest</th><th>Status</th><th>Update</th></tr></thead><tbody>${volunteers.map(v=>`<tr><td>${esc(v.name)}<br>${esc(v.email)}<br>${esc(v.phone)}</td><td>${esc(v.interest)}</td><td>${esc(v.status)}</td><td><select data-volunteer-status="${v.id}"><option ${v.status==="New"?"selected":""}>New</option><option ${v.status==="Contacted"?"selected":""}>Contacted</option><option ${v.status==="Approved"?"selected":""}>Approved</option><option ${v.status==="Declined"?"selected":""}>Declined</option></select></td></tr>`).join("")}</tbody></table>`:'<div class="empty-state">No volunteer requests yet.</div>';
 }catch(err){$("#adminDonations").innerHTML=`<p class="muted">${esc(err.message)}</p>`}
}
document.addEventListener("click",async e=>{const b=e.target.closest("[data-verify]");if(b){b.disabled=true;try{await api(`/admin/donations/${b.dataset.verify}/verify`,{method:"PATCH"});showDashboard();await loadHome()}catch(err){alert(err.message);b.disabled=false}}});
document.addEventListener("change",async e=>{const s=e.target.closest("[data-volunteer-status]");if(s){try{await api(`/admin/volunteers/${s.dataset.volunteerStatus}?status=${encodeURIComponent(s.value)}`,{method:"PATCH"});s.style.borderColor="#9bc65b"}catch(err){alert(err.message)}}});
$("#logoutBtn").addEventListener("click",async()=>{try{await api("/auth/logout",{method:"POST"})}catch{}authToken="";currentUser=null;localStorage.removeItem("hope_token");localStorage.removeItem("hope_user");closeModals()});
$("#year").textContent=new Date().getFullYear();
loadHome();
